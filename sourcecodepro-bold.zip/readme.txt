字由（hellofont）使用教程

方法1：
1.打开设计软件（如ps、ai）
2.新建文档，输入文字内容
3.打开字由，在客户端选择想要的字体，点击激活（呼吸灯变绿表示激活成功）
4.点击字体图层，再点激活过的字体
5.字体变化，应用成功

方法2：
1.在客户端点击激活想要使用的字体
2.打开设计软件（如ps、ai），在字体列表里选择相应字体并应用

Windows客户端下载：hhttps://hellofont.oss-cn-beijing.aliyuncs.com/oem/HelloFont.win.zkdetail.zip
Mac OS客户端下载：https://hellofont.oss-cn-beijing.aliyuncs.com/oem/HelloFont.mac.zkdetail.dmg

目前支持字由客户端的软件：
Photoshop，Illustrator，Indesign（暂支持Mac OS客户端），CorelDRAW，Sketch，Word（仅支持Microsoft Office），PowerPoint（仅支持Microsoft Office），Keynote

故障解决：如遇到激活字体失败的提示，请在打开字由客户端前，打开电脑本地日期和时间更改界面，把时区调整成北京

字由官网：https://www.hellofont.cn/

字由微信公众号：字由（hellofont）